import { useEffect, useRef, useState } from "react";
import { Pause, Play } from "lucide-react";
import { Button } from "@/components/ui/button";

/** Decorative, synthetic candles. Never represents an account or live prices. */
export function TradingMotion() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let width = 0;
    let height = 0;
    let elapsed = 0;
    let previous = 0;
    let colors = { grid: "", up: "", down: "", label: "" };
    const readColors = () => {
      const css = getComputedStyle(document.documentElement);
      colors = {
        grid: css.getPropertyValue("--chart-grid").trim(),
        up: css.getPropertyValue("--chart-up").trim(),
        down: css.getPropertyValue("--chart-down").trim(),
        label: css.getPropertyValue("--chart-label").trim(),
      };
    };
    const price = (i: number) => 50 + Math.sin(i * 0.38) * 12 + Math.sin(i * 0.91) * 5 + Math.sin(i * 0.13) * 15;
    const draw = (time: number) => {
      if (previous && !paused && !reduced.matches && !document.hidden) elapsed += Math.min(time - previous, 50);
      previous = time;
      context.clearRect(0, 0, width, height);
      context.strokeStyle = colors.grid;
      context.lineWidth = 1;
      for (let y = 65; y < height; y += 70) {
        context.beginPath(); context.moveTo(0, y); context.lineTo(width, y); context.stroke();
      }
      for (let x = 0; x < width; x += 80) {
        context.beginPath(); context.moveTo(x, 0); context.lineTo(x, height); context.stroke();
      }
      const spacing = width < 600 ? 24 : 32;
      const count = Math.ceil(width / spacing) + 2;
      const progress = elapsed / 2200;
      const shift = Math.floor(progress);
      const fraction = progress - shift;
      const plot = height * 0.66;
      const yFor = (p: number) => height * 0.2 + (85 - p) / 70 * plot;
      for (let i = 0; i < count; i++) {
        const n = i + shift;
        const open = price(n);
        const close = price(n + 1);
        const x = (i - fraction) * spacing;
        const high = Math.max(open, close) + 3 + Math.abs(Math.sin(n)) * 5;
        const low = Math.min(open, close) - 3 - Math.abs(Math.cos(n)) * 5;
        context.strokeStyle = context.fillStyle = close >= open ? colors.up : colors.down;
        context.globalAlpha = 0.9;
        context.beginPath(); context.moveTo(x, yFor(high)); context.lineTo(x, yFor(low)); context.stroke();
        context.fillRect(x - spacing * 0.2, Math.min(yFor(open), yFor(close)), spacing * 0.4, Math.max(3, Math.abs(yFor(open) - yFor(close))));
        context.globalAlpha = 0.15;
        context.fillRect(x - spacing * 0.2, height - 16 - Math.abs(Math.sin(n * 0.7)) * 48, spacing * 0.4, 64);
      }
      context.globalAlpha = 1;
      context.fillStyle = colors.label;
      context.font = "11px monospace";
      for (let y = 65; y < height - 75; y += 70) context.fillText((2440 - y / height * 45).toFixed(2), width - 60, y - 8);
      frame = requestAnimationFrame(draw);
    };
    const resize = () => {
      const bounds = canvas.getBoundingClientRect();
      width = bounds.width; height = bounds.height;
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = width * ratio; canvas.height = height * ratio;
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      readColors();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    const themeObserver = new MutationObserver(readColors);
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    resize();
    frame = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(frame); observer.disconnect(); themeObserver.disconnect(); };
  }, [paused]);

  return (
    <>
      <div className="trading-scene" aria-hidden="true"><canvas ref={canvasRef} /></div>
      <div className="chart-caption">
        <span><strong>XAUUSD / M5</strong><span className="block">Illustrative chart · not live data</span></span>
        <Button variant="ghost" size="icon" onClick={() => setPaused((v) => !v)} aria-label={paused ? "Play candle animation" : "Pause candle animation"} title={paused ? "Play candle animation" : "Pause candle animation"}>
          {paused ? <Play /> : <Pause />}
        </Button>
      </div>
    </>
  );
}