export type RegionKey = "us" | "uk" | "ae";

export const CONTACT = {
  whatsapp: "[WHATSAPP_NUMBER]",
  whatsappUrl: "https://wa.me/", // append number once known
  telegram: "[TELEGRAM_LINK]",
  telegramUrl: "https://t.me/",
  email: "[EMAIL_ADDRESS]",
  myfxbook: "[MYFXBOOK_URL]",
};

export const REGIONS: Record<
  RegionKey,
  {
    label: string;
    lang: string;
    title: string;
    description: string;
    h1: string;
    sub: string;
    hours: string;
    currencyNote: string;
    contactOrder: ("whatsapp" | "telegram" | "email")[];
    footer: string;
    risk: string;
    behaviour: string;
  }
> = {
  us: {
    label: "United States",
    lang: "en-US",
    title: "Gold EA for MT5 | Managed VPS & License | AuraFXAlgo",
    description:
      "Licensed XAUUSD Expert Advisor for MetaTrader 5 with a managed VPS included. Software only. Funds stay in your broker account. High risk.",
    h1: "Gold (XAUUSD) Expert Advisor for MetaTrader 5, With a Managed VPS Included",
    sub: "A licensed grid EA for gold on M5. We host it on a VPS; your money stays in your own broker account. Software only.",
    hours: "Support: Mon–Fri, 9:00–18:00 ET",
    currencyNote: "Prices in USD.",
    contactOrder: ["email", "telegram", "whatsapp"],
    footer:
      "Hypothetical or simulated performance results have inherent limitations and do not represent actual trading. Backtests are not indicative of future results. AuraFXAlgo provides software only and is not a registered investment adviser, broker-dealer, or CTA. No content is investment advice.",
    risk: "Leveraged trading carries a high risk of loss. Past results do not guarantee future results. Software only, not investment advice.",
    behaviour: "behavior",
  },
  uk: {
    label: "United Kingdom",
    lang: "en-GB",
    title: "Gold EA for MT5 UK | Managed VPS & Licence | AuraFXAlgo",
    description:
      "Licensed XAUUSD Expert Advisor for MT5 with a managed VPS included, for UK traders. Software only, not a recommendation. CFDs carry high risk.",
    h1: "Gold (XAUUSD) Expert Advisor for MetaTrader 5, With a Managed VPS Included",
    sub: "A licensed grid EA for gold on M5, hosted on a managed VPS. Your funds stay with your own broker. Software only, not a personal recommendation.",
    hours: "Support: Mon–Fri, 09:00–17:30 UK time",
    currencyNote: "Prices charged in USD; your card provider converts to GBP.",
    contactOrder: ["email", "telegram", "whatsapp"],
    footer:
      "CFDs are complex instruments and come with a high risk of losing money rapidly due to leverage. You should consider whether you understand how CFDs work and whether you can afford to take the high risk of losing your money. This page is not a financial promotion or a personal recommendation. AuraFXAlgo supplies software only.",
    risk: "CFDs are complex instruments with a high risk of losing money rapidly due to leverage. Past performance is not a reliable indicator. Software only, not advice.",
    behaviour: "behaviour",
  },
  ae: {
    label: "UAE / Dubai",
    lang: "en-AE",
    title: "Gold EA for MT5 Dubai & UAE | Managed VPS | AuraFXAlgo",
    description:
      "XAUUSD Expert Advisor for MT5 with managed VPS, for traders in Dubai and the UAE. USD pricing, WhatsApp support. Software only. High risk.",
    h1: "Gold (XAUUSD) Expert Advisor for MetaTrader 5, With a Managed VPS Included",
    sub: "A licensed grid EA for gold on M5, hosted on a managed VPS. Funds stay in your broker account. WhatsApp support in Gulf hours.",
    hours: "Support: Sun–Fri, 10:00–19:00 GST (WhatsApp first)",
    currencyNote: "Prices in USD (approx. AED shown at 3.6725 AED/USD).",
    contactOrder: ["whatsapp", "telegram", "email"],
    footer:
      "AuraFXAlgo provides software only. We do not provide brokerage, investment advice, or account management, and we do not hold client funds. Check that your broker is authorised in your country of residence before trading. Leveraged trading carries a high risk of loss.",
    risk: "Leveraged trading carries a high risk of loss. Past results do not guarantee future results. Software only, not investment advice.",
    behaviour: "behaviour",
  },
};

export const PLANS = [
  { name: "Starter", accounts: 1, price: 99, popular: false },
  { name: "Pro", accounts: 3, price: 179, popular: true },
  { name: "Elite", accounts: 7, price: 299, popular: false },
];

export const BILLING = {
  monthly: { label: "Monthly", months: 1, discount: 0 },
  quarterly: { label: "Quarterly", months: 3, discount: 0.1 },
  yearly: { label: "Yearly", months: 12, discount: 0.2 },
} as const;

export const FAQ: { q: string; a: string }[] = [
  { q: "What is a gold EA?", a: "A gold EA is software that places and manages XAUUSD trades automatically inside MetaTrader 5, following fixed rules. AuraFXAlgo is one such EA, licensed per account." },
  { q: "Does an EA guarantee profit?", a: "No. No EA can guarantee profit. Gold is volatile and leveraged trading can lose more than you expect, including your full deposit." },
  { q: "Is my money safe?", a: "Your money stays in your own broker account; we never hold or touch funds. That does not make trading safe: the EA can and does produce losses and large drawdowns." },
  { q: "Do you manage my account?", a: "No. We sell a software licence and host it on a VPS. You choose the broker, the preset, and when to start or stop." },
  { q: "What is the maximum drawdown?", a: "The maximum recorded equity drawdown is [X%] on the live Myfxbook account as of [date]. Future drawdowns can be larger." },
  { q: "Is it a grid EA?", a: "Yes. AuraFXAlgo is a grid strategy. It adds positions as price moves against the first trade and closes the basket at a combined profit, so it can hold large floating losses." },
  { q: "Do I need my own VPS?", a: "No. Every licence includes one managed VPS, set up and monitored by us." },
  { q: "Which brokers work?", a: "Any MT5 broker offering a hedging account and XAUUSD (or GOLD). ECN/Raw accounts are recommended. Tested so far: [broker list]." },
  { q: "Can I withdraw or stop anytime?", a: "Yes. Your funds are in your broker account, so you can withdraw or switch the EA off at any time. Closing during a drawdown locks in the floating loss." },
  { q: "What is the refund policy?", a: "You can request a full refund within [7/14] days of your first payment. Renewals are not refunded once the billing period starts." },
  { q: "What if the VPS goes down?", a: "We monitor every VPS and restart or migrate it if it fails. Open trades stay on the broker's server, but the EA cannot manage them while offline." },
  { q: "Is this financial advice?", a: "No. AuraFXAlgo is software only. Nothing on this page is investment advice or a personal recommendation." },
];
