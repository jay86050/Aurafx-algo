import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BILLING, CONTACT, FAQ, PLANS, REGIONS, type RegionKey } from "@/lib/regions";
import { TradingMotion } from "@/components/trading-motion";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, Sun, Moon, ChartCandlestick } from "lucide-react";

type Search = { region?: RegionKey };

export const Route = createFileRoute("/")({
  validateSearch: (s: Record<string, unknown>): Search => {
    const r = s["region"];
    return r === "uk" || r === "ae" || r === "us" ? { region: r } : {};
  },
  loaderDeps: ({ search }) => ({ region: search.region ?? "us" }),
  loader: ({ deps }) => ({ region: deps.region as RegionKey }),
  head: ({ loaderData }) => {
    const key = loaderData?.region ?? "us";
    const r = REGIONS[key];
    const url = key === "us" ? "/" : `/?region=${key}`;
    const offers = PLANS.map((p) => ({
      "@type": "Offer",
      name: p.name,
      price: p.price,
      priceCurrency: "USD",
      description: `${p.accounts} account licence(s) with ${p.accounts} managed VPS`,
    }));
    return {
      meta: [
        { title: r.title },
        { name: "description", content: r.description },
        { property: "og:title", content: r.title },
        { property: "og:description", content: r.description },
        { property: "og:type", content: "website" },
        { property: "og:url", content: url },
        { property: "og:locale", content: r.lang.replace("-", "_") },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: r.title },
        { name: "twitter:description", content: r.description },
      ],
      links: [
        { rel: "canonical", href: url },
        { rel: "alternate", hrefLang: "en-US", href: "/" },
        { rel: "alternate", hrefLang: "en-GB", href: "/?region=uk" },
        { rel: "alternate", hrefLang: "en-AE", href: "/?region=ae" },
        { rel: "alternate", hrefLang: "x-default", href: "/" },
      ],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify([
            {
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "AuraFXAlgo",
              description: "Licensed MT5 Expert Advisor for gold (XAUUSD) with a managed VPS. Software only.",
              sameAs: ["[MYFXBOOK_URL]", "[TELEGRAM_URL]", "[YOUTUBE_URL]", "[LINKEDIN_URL]"],
            },
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              name: "AuraFXAlgo Gold EA",
              applicationCategory: "FinanceApplication",
              operatingSystem: "MetaTrader 5 (Windows VPS)",
              offers,
            },
            {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              mainEntity: FAQ.map((f) => ({
                "@type": "Question",
                name: f.q,
                acceptedAnswer: { "@type": "Answer", text: f.a },
              })),
            },
            {
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
              itemListElement: [{ "@type": "ListItem", position: 1, name: "Home", item: url }],
            },
          ]),
        },
      ],
    };
  },
  component: Landing,
});

const P = ({ children }: { children: React.ReactNode }) => <span className="ph">{children}</span>;

const PRESETS = [
  { key: "conservative", name: "Conservative", min: "[$X]", minNum: 5000, lotPer1k: 0.01 / 5, dd: "[X–Y%]" },
  { key: "balanced", name: "Balanced", min: "[$X]", minNum: 3000, lotPer1k: 0.01 / 3, dd: "[X–Y%]" },
  { key: "aggressive", name: "Aggressive", min: "[$X]", minNum: 2000, lotPer1k: 0.01 / 2, dd: "[X–Y%]" },
];

function Landing() {
  const { region } = Route.useLoaderData();
  const r = REGIONS[region];
  const [light, setLight] = useState(false);
  const [billing, setBilling] = useState<keyof typeof BILLING>("monthly");
  const [balance, setBalance] = useState(5000);
  const [preset, setPreset] = useState("balanced");
  const [consent, setConsent] = useState<string | null>("pending");
  const [bannerHidden, setBannerHidden] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem("theme");
    const isLight = saved === "light";
    setLight(isLight);
    setConsent(localStorage.getItem("consent"));
    setBannerHidden(localStorage.getItem("regionBanner") === "1");
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle("light", light);
    document.documentElement.lang = r.lang;
  }, [light, r.lang]);

  const acceptConsent = (v: string) => {
    localStorage.setItem("consent", v);
    setConsent(v);
    // Analytics would be loaded here only when v === "accepted".
  };

  const toggleTheme = () => {
    const next = !light;
    setLight(next);
    localStorage.setItem("theme", next ? "light" : "dark");
  };

  const b = BILLING[billing];
  const priceFor = (base: number) => base * b.months * (1 - b.discount);
  const fmt = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
  const aed = (n: number) => `≈ AED ${Math.round(n * 3.6725).toLocaleString("en-US")}`;

  const calc = useMemo(() => {
    const p = PRESETS.find((x) => x.key === preset)!;
    const lot = Math.max(0, Math.floor((balance / 1000) * p.lotPer1k * 100) / 100);
    return { p, lot, below: balance < p.minNum };
  }, [balance, preset]);

  const contacts = {
    whatsapp: { label: "WhatsApp", value: CONTACT.whatsapp, href: CONTACT.whatsappUrl },
    telegram: { label: "Telegram", value: CONTACT.telegram, href: CONTACT.telegramUrl },
    email: { label: "Email", value: CONTACT.email, href: `mailto:${CONTACT.email}` },
  };

  const RegionLinks = ({ className = "" }: { className?: string }) => (
    <div className={`flex gap-1 ${className}`} role="group" aria-label="Switch region">
      {(Object.keys(REGIONS) as RegionKey[]).map((k) => (
        <Link
          key={k}
          to="/"
          search={k === "us" ? {} : { region: k }}
          hrefLang={REGIONS[k].lang}
          aria-current={k === region ? "true" : undefined}
          className={`tap inline-flex items-center justify-center rounded-md px-2 text-xs font-bold uppercase ${
            k === region ? "bg-accent text-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          {k === "ae" ? "UAE" : k.toUpperCase()}
        </Link>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      {/* 1. Risk bar */}
      <div className="bg-warning text-warning-foreground text-center text-xs sm:text-sm px-4 py-2">{r.risk}</div>

      {!bannerHidden && (
        <div className="bg-secondary text-sm">
          <div className="container-page flex flex-wrap items-center justify-between gap-2 py-2">
            <span>
              Viewing the <strong>{r.label}</strong> version. Not your region?
            </span>
            <div className="flex items-center gap-2">
              <RegionLinks />
              <button
                className="tap text-muted-foreground hover:text-foreground"
                aria-label="Dismiss region banner"
                onClick={() => {
                  localStorage.setItem("regionBanner", "1");
                  setBannerHidden(true);
                }}
              >
                ✕
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
        <div className="container-page flex h-16 items-center justify-between gap-4">
          <a href="#top" className="font-display text-xl font-semibold flex items-center gap-2" aria-label="AuraFXAlgo home">
            <ChartCandlestick className="size-6 text-primary" aria-hidden="true" />
            <span>Aura<span className="text-primary">FX</span>Algo</span>
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-muted-foreground" aria-label="Main">
            <a href="#results" className="hover:text-foreground">Results</a>
            <a href="#pricing" className="hover:text-foreground">Pricing</a>
            <a href="#faq" className="hover:text-foreground">FAQ</a>
          </nav>
          <div className="flex items-center gap-2">
            <RegionLinks className="hidden sm:flex" />
            <Button variant="ghost" size="icon" onClick={toggleTheme} className="tap text-muted-foreground" aria-label={light ? "Switch to dark mode" : "Switch to light mode"} title={light ? "Switch to dark mode" : "Switch to light mode"}>
              {light ? <Moon /> : <Sun />}
            </Button>
            <Button asChild className="hidden sm:inline-flex min-h-11"><a href="#pricing">View Plans <ArrowUpRight /></a></Button>
          </div>
        </div>
      </header>

      <main id="top">
        {/* 2. Hero */}
        <section className="trading-hero">
          <TradingMotion />
          <div className="container-page hero-content">
            <div className="hero-enter">
            <p className="eyebrow">MT5 · XAUUSD · M5 · Grid strategy</p>
            <h1 className="mt-4">Aura<span className="text-primary">FX</span>Algo</h1>
            <p className="hero-product mt-5 font-medium">{r.h1}</p>
            <p className="hero-description mt-5 text-base text-muted-foreground">{r.sub}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="min-h-12"><a href="#pricing">View Plans <ArrowUpRight /></a></Button>
              <Button asChild variant="outline" size="lg" className="min-h-12 bg-background/70"><a href="#results">See Live Results</a></Button>
            </div>
            </div>
            <ul className="hero-facts mt-10 grid gap-3 text-xs text-muted-foreground sm:grid-cols-2 lg:grid-cols-4">
              <li>Live since <P>[Month Year]</P></li>
              <li>Verified on <a className="underline" href="#results">Myfxbook</a></li>
              <li>Max equity drawdown <P>[X%]</P> (as of <P>[date]</P>)</li>
              <li>Active accounts <P>[N]</P></li>
            </ul>
          </div>
        </section>

        {/* 3. Live results */}
        <section id="results" className="section border-t">
          <div className="container-page">
            <p className="eyebrow">Live results</p>
            <h2 className="mt-3">Verified live performance, losses included</h2>
            <p className="mt-4 text-muted-foreground">
              These figures come from one live, third-party verified Myfxbook account. Equity drawdown is shown at the same size as gain because it matters as much.
            </p>
            <div className="card mt-8 flex aspect-[16/7] items-center justify-center p-6 text-center text-muted-foreground">
              <div>
                <p className="font-semibold">Myfxbook widget placeholder</p>
                <p className="text-sm">Embed from <P>[MYFXBOOK_URL]</P></p>
              </div>
            </div>
            <div className="mt-6 grid gap-4 grid-cols-2 lg:grid-cols-5">
              {[
                ["Max equity drawdown", "[X%]", true],
                ["Total gain", "[X%]", true],
                ["Months live", "[X]", false],
                ["Win rate", "[X%]", false],
                ["Profit factor", "[X]", false],
              ].map(([label, val, big]) => (
                <div key={label as string} className={`card p-5 ${big ? "col-span-2 lg:col-span-1" : ""}`}>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
                  <p className="stat-num mt-2 text-primary">{val}</p>
                </div>
              ))}
            </div>
            <div className="card mt-6 overflow-x-auto">
              <table className="data-table">
                <caption className="sr-only">Monthly returns, live account</caption>
                <thead><tr><th>Month</th><th>Return</th><th>Max equity DD</th></tr></thead>
                <tbody>
                  {["[Month 1]", "[Month 2]", "[Month 3]", "[Month 4]"].map((m) => (
                    <tr key={m}><td>{m}</td><td><P>[±X%]</P></td><td><P>[X%]</P></td></tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              Source: Myfxbook <P>[URL]</P>, data as of <P>[date]</P>. Losing months are included. Single-month backtests are not shown.
            </p>
          </div>
        </section>

        {/* 4. What it is */}
        <section className="section border-t">
          <div className="container-page grid gap-10 lg:grid-cols-2">
            <div>
              <p className="eyebrow">What is AuraFXAlgo</p>
              <h2 className="mt-3">A licensed gold EA for MT5, hosted for you</h2>
              <p className="mt-4 text-muted-foreground">
                AuraFXAlgo is an Expert Advisor that trades XAUUSD on the M5 chart inside your own MT5 account. You buy a licence; we run it on a managed VPS. We never hold your funds or manage your account.
              </p>
              <h3 className="mt-8">How the strategy works</h3>
              <ul className="mt-4 space-y-2 text-muted-foreground list-disc pl-5">
                <li>Entries are based on price relative to VWAP.</li>
                <li>Spread and time filters skip poor trading conditions.</li>
                <li>The first trade has a quick take-profit.</li>
                <li>If price moves against it, the EA adds grid positions, capped by a lot limit.</li>
                <li>The basket closes at a combined profit, with trailing.</li>
              </ul>
            </div>
            <aside className="card self-start border-destructive/50 p-6" aria-labelledby="grid-risk">
              <p className="eyebrow text-destructive">Risk</p>
              <h3 id="grid-risk" className="mt-2">This is a grid strategy</h3>
              <p className="mt-3 text-muted-foreground">
                Grid EAs hold open positions while price moves against them. That can create large floating (equity) drawdowns, sometimes far deeper than your balance shows. A strong one-way gold move can cause heavy losses or a margin call. Only trade money you can afford to lose.
              </p>
            </aside>
          </div>
        </section>

        {/* 5. Steps */}
        <section className="section border-t">
          <div className="container-page">
            <p className="eyebrow">How it works</p>
            <h2 className="mt-3">Running in three steps</h2>
            <ol className="mt-8 grid gap-4 md:grid-cols-3">
              {[
                ["Choose a plan", "Pick how many MT5 accounts you want to license."],
                ["Share MT5 login", "Send your broker server and trading login. Funds stay with your broker."],
                ["We deploy on VPS", "We install the EA with your chosen preset and confirm it's live."],
              ].map(([t, d], i) => (
                <li key={t} className="card p-6">
                  <span className="stat-num text-primary">0{i + 1}</span>
                  <h3 className="mt-3">{t}</h3>
                  <p className="mt-2 text-muted-foreground">{d}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* 6. Included */}
        <section className="section border-t">
          <div className="container-page">
            <p className="eyebrow">What's included</p>
            <h2 className="mt-3">Everything to run the EA, per account</h2>
            <ul className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {[
                "One MT5 EA licence per account",
                "Managed Windows VPS per account",
                "Installation and preset setup",
                "VPS uptime monitoring",
                "EA updates during your plan",
                `Support — ${r.hours.replace("Support: ", "")}`,
              ].map((x) => (
                <li key={x} className="card flex gap-3 p-5"><span className="text-primary" aria-hidden>◆</span>{x}</li>
              ))}
            </ul>
          </div>
        </section>

        {/* 7. Calculator */}
        <section className="section border-t">
          <div className="container-page grid gap-10 lg:grid-cols-2">
            <div>
              <p className="eyebrow">Risk calculator</p>
              <h2 className="mt-3">See a starting lot for your balance</h2>
              <p className="mt-4 text-muted-foreground">
                Enter your balance and preset to see a suggested starting lot and the historical drawdown range. This is an illustration, not a forecast.
              </p>
            </div>
            <div className="card p-6">
              <label className="block text-sm font-semibold" htmlFor="bal">Account balance (USD)</label>
              <input id="bal" type="number" min={0} step={100} value={balance}
                onChange={(e) => setBalance(Number(e.target.value) || 0)}
                className="mt-2 w-full min-h-11 rounded-md border border-input bg-background px-3" />
              <label className="mt-4 block text-sm font-semibold" htmlFor="pre">Preset</label>
              <select id="pre" value={preset} onChange={(e) => setPreset(e.target.value)}
                className="mt-2 w-full min-h-11 rounded-md border border-input bg-background px-3">
                {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.name}</option>)}
              </select>
              <dl className="mt-6 grid grid-cols-2 gap-4">
                <div><dt className="text-xs uppercase text-muted-foreground">Starting lot</dt><dd className="stat-num text-primary">{calc.lot.toFixed(2)}</dd></div>
                <div><dt className="text-xs uppercase text-muted-foreground">Historical DD range</dt><dd className="stat-num">{calc.p.dd}</dd></div>
              </dl>
              {calc.below && <p className="mt-4 text-sm text-destructive">Below the recommended minimum for this preset.</p>}
              <p className="mt-4 text-xs text-muted-foreground">
                Lot formula is a placeholder until real preset settings are supplied. Not a forecast; future drawdowns may exceed historical ranges.
              </p>
            </div>
          </div>
        </section>

        {/* 8. Pricing */}
        <section id="pricing" className="section border-t">
          <div className="container-page">
            <p className="eyebrow">Pricing</p>
            <h2 className="mt-3">One licence and one VPS per account</h2>
            <p className="mt-4 text-muted-foreground">Pick the number of accounts. Longer billing periods are discounted. {r.currencyNote}</p>
            <div className="mt-6 inline-flex rounded-lg border p-1" role="radiogroup" aria-label="Billing period">
              {(Object.keys(BILLING) as (keyof typeof BILLING)[]).map((k) => (
                <button key={k} role="radio" aria-checked={billing === k} onClick={() => setBilling(k)}
                  className={`tap rounded-md px-4 text-sm font-semibold ${billing === k ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                  {BILLING[k].label}{BILLING[k].discount ? ` −${BILLING[k].discount * 100}%` : ""}
                </button>
              ))}
            </div>
            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {PLANS.map((p) => {
                const total = priceFor(p.price);
                return (
                  <article key={p.name} className={`card relative flex flex-col p-6 ${p.popular ? "border-primary md:-translate-y-2" : ""}`}>
                    {p.popular && <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-0.5 text-xs font-bold text-primary-foreground">Most popular</span>}
                    <h3>{p.name}</h3>
                    <p className="mt-4"><span className="stat-num text-primary">{fmt(total)}</span> <span className="text-muted-foreground">/ {b.label.toLowerCase().replace("ly", "")}</span></p>
                    {region === "ae" && <p className="text-sm text-muted-foreground">{aed(total)}</p>}
                    <p className="mt-1 text-sm text-muted-foreground">{fmt(total / p.accounts)} per account</p>
                    <ul className="mt-5 space-y-2 text-sm">
                      <li>{p.accounts} MT5 account{p.accounts > 1 && "s"}</li>
                      <li>{p.accounts} licence{p.accounts > 1 && "s"}</li>
                      <li>{p.accounts} managed VPS</li>
                    </ul>
                    <a href="#" className={`btn mt-6 ${p.popular ? "btn-gold" : "btn-ghost"}`}>Choose {p.name}</a>
                  </article>
                );
              })}
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Refund: full refund within <P>[7/14]</P> days of first payment. Pro and Elite prices are assumptions until confirmed.
            </p>
            <div className="card mt-8 overflow-x-auto">
              <table className="data-table">
                <caption className="sr-only">Plan comparison</caption>
                <thead><tr><th>Plan</th><th>Accounts</th><th>Licences</th><th>VPS</th><th>Monthly price</th><th>Per account</th></tr></thead>
                <tbody>{PLANS.map((p) => (
                  <tr key={p.name}><td>{p.name}</td><td>{p.accounts}</td><td>{p.accounts}</td><td>{p.accounts}</td><td>{fmt(p.price)}</td><td>{fmt(p.price / p.accounts)}</td></tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </section>

        {/* 9. Presets & requirements */}
        <section className="section border-t">
          <div className="container-page grid gap-10 lg:grid-cols-2">
            <div>
              <h2>Risk presets</h2>
              <p className="mt-3 text-muted-foreground">Each preset trades the same rules with different lot sizing. Higher risk means deeper drawdowns.</p>
              <div className="card mt-6 overflow-x-auto">
                <table className="data-table">
                  <thead><tr><th>Preset</th><th>Min. balance</th><th>Hist. equity DD</th></tr></thead>
                  <tbody>{PRESETS.map((p) => <tr key={p.key}><td>{p.name}</td><td><P>{p.min}</P></td><td><P>{p.dd}</P></td></tr>)}</tbody>
                </table>
              </div>
            </div>
            <div>
              <h2>Broker requirements</h2>
              <p className="mt-3 text-muted-foreground">You need an MT5 hedging account with gold available. ECN or Raw spreads work best.</p>
              <div className="card mt-6 overflow-x-auto">
                <table className="data-table">
                  <tbody>
                    {[
                      ["Platform", "MetaTrader 5"],
                      ["Account type", "Hedging (not netting)"],
                      ["Symbol", "XAUUSD or GOLD (suffixes OK)"],
                      ["Spread", "ECN / Raw recommended"],
                      ["Leverage", "[1:X] or higher"],
                      ["Minimum balance", "See presets"],
                      ["Tested brokers", "[broker list]"],
                    ].map(([k, v]) => <tr key={k}><th scope="row">{k}</th><td>{v}</td></tr>)}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>

        {/* 10. Who for */}
        <section className="section border-t">
          <div className="container-page grid gap-5 md:grid-cols-2">
            <div className="card p-6">
              <h2 className="text-3xl">Who it's for</h2>
              <ul className="mt-4 space-y-2 list-disc pl-5 text-muted-foreground">
                <li>Traders who understand grid {r.behaviour} and drawdown</li>
                <li>People who want automation without running their own VPS</li>
                <li>Those using risk capital they can afford to lose</li>
              </ul>
            </div>
            <div className="card p-6">
              <h2 className="text-3xl">Who it's not for</h2>
              <ul className="mt-4 space-y-2 list-disc pl-5 text-muted-foreground">
                <li>Anyone needing steady monthly income</li>
                <li>Anyone who can't tolerate large floating losses</li>
                <li>Anyone looking for investment advice or account management</li>
              </ul>
            </div>
          </div>
        </section>

        {/* 11. Testimonials hidden until real ones exist */}

        {/* 12. FAQ */}
        <section id="faq" className="section border-t">
          <div className="container-page max-w-3xl">
            <p className="eyebrow">FAQ</p>
            <h2 className="mt-3">Straight answers</h2>
            <div className="mt-8 divide-y border-y">
              {FAQ.map((f) => (
                <details key={f.q} className="group py-2">
                  <summary className="tap flex cursor-pointer list-none items-center justify-between gap-4 py-3 font-semibold">
                    <h3 className="font-sans text-base font-semibold">{f.q}</h3>
                    <span className="text-primary transition-transform group-open:rotate-45" aria-hidden>+</span>
                  </summary>
                  <p className="pb-4 text-muted-foreground">{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* 13. Final CTA */}
        <section className="section border-t hero-glow">
          <div className="container-page text-center">
            <h2>Ready to run the EA on your own account?</h2>
            <p className="mx-auto mt-4 text-muted-foreground">Read the risks, check the live results, then pick a plan.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <a href="#pricing" className="btn btn-gold">View Plans</a>
              <a href="#results" className="btn btn-ghost">See Live Results</a>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-card">
        <div className="container-page py-12 text-sm text-muted-foreground">
          <div className="grid gap-8 md:grid-cols-3">
            <div>
              <p className="font-display text-2xl text-foreground">Aura<span className="text-primary">FX</span>Algo</p>
              <p className="mt-2">Licensed MT5 gold EA with managed VPS. Software only.</p>
            </div>
            <div>
              <p className="font-semibold text-foreground">Contact</p>
              <p className="mt-1">{r.hours}</p>
              <ul className="mt-2 space-y-1">
                {r.contactOrder.map((c) => (
                  <li key={c}><a className="underline" href={contacts[c].href}>{contacts[c].label}</a>: <P>{contacts[c].value}</P></li>
                ))}
              </ul>
            </div>
            <div>
              <p className="font-semibold text-foreground">Legal</p>
              <ul className="mt-2 space-y-1">
                {["Terms", "Privacy", "Refund Policy", "Risk Disclosure"].map((l) => <li key={l}><a href="#" className="underline">{l}</a></li>)}
              </ul>
              <p className="mt-4 font-semibold text-foreground">Region</p>
              <RegionLinks className="mt-1" />
            </div>
          </div>
          <div className="mt-10 space-y-3 border-t pt-6 text-xs leading-relaxed">
            <p><strong>Risk disclosure.</strong> {r.footer}</p>
            <p>AuraFXAlgo sells software only. Client funds remain in the client's own broker account. We do not manage accounts, hold funds, or give investment advice. Grid strategies can produce large drawdowns, including loss of the entire deposit.</p>
            <p>© {new Date().getFullYear()} AuraFXAlgo.</p>
          </div>
        </div>
      </footer>

      {/* Floating contact */}
      <div className="fixed bottom-24 right-4 z-40 flex flex-col gap-2 md:bottom-6">
        <a href={CONTACT.whatsappUrl} aria-label="Chat on WhatsApp" className="tap btn btn-gold rounded-full px-0 text-xs">WA</a>
        <a href={CONTACT.telegramUrl} aria-label="Message on Telegram" className="tap btn btn-ghost rounded-full bg-card px-0 text-xs">TG</a>
      </div>

      {/* Mobile sticky CTA */}
      <div className="fixed inset-x-0 bottom-0 z-30 border-t bg-background/95 p-3 backdrop-blur md:hidden">
        <a href="#pricing" className="btn btn-gold w-full">View Plans — from $99</a>
      </div>

      {/* Cookie consent */}
      {consent === null && (
        <div role="dialog" aria-label="Cookie consent" className="fixed inset-x-3 bottom-20 z-50 card p-4 shadow-xl md:bottom-4 md:left-4 md:right-auto md:max-w-sm">
          <p className="text-sm">We use analytics cookies only with your consent.</p>
          <div className="mt-3 flex gap-2">
            <button className="btn btn-gold" onClick={() => acceptConsent("accepted")}>Accept</button>
            <button className="btn btn-ghost" onClick={() => acceptConsent("declined")}>Decline</button>
          </div>
        </div>
      )}
    </div>
  );
}
